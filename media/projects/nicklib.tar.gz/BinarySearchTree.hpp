/****************************************************************************
 * BinarySearchTree.hpp 
 * Templated Binary Search Tree functiono implementations
 *
 * Programmer: Nick Pegg		Date: March 29, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Binary Search Tree class: a collection of nodes which contain
 * data and links to two other nodes. Does not allow duplicates.
 * 
 ****************************************************************************/

/* Accessor Functions
*****************************************************************************/
template <class tpl>
BNode<tpl>* BinarySearchTree<tpl>::find(tpl data, BNode<tpl>* root) {
	if (root != NULL) {
		if (root->getData() == data) 
			return(root);	//We've found our guy!
		else if (root->getData() > data)
			return(find(data, root->getLeft()));	//Go left
		else if (root->getData() < data)
			return(find(data, root->getRight())); //Go right
		else
			return(NULL);
	}
	else
		return(NULL);	//We couldn't find our person
}

template <class tpl>
BNode<tpl>* BinarySearchTree<tpl>::findParent(tpl data, BNode<tpl>* root) {
	if (root != NULL) {
		BNode<tpl>* check;
		if (root->getData() == data) 
			return(NULL);	//We've found our guy!
		else if (root->getData() > data)
			check = findParent(data, root->getLeft());	//Go left
		else if (root->getData() < data)
			check = findParent(data, root->getRight()); //Go right
		else
			return(NULL);

		if (check == NULL) {
			return(root);
		} else
			return(check);
	}
	else
		return(NULL);	//We couldn't find our person
}

template <class tpl>
BNode<tpl>* BinarySearchTree<tpl>::findParentByNode(BNode<tpl>* nodePtr, BNode<tpl>* root) {
	if (root != NULL) {
		BNode<tpl>* ret;

		if (root->getLeft() == nodePtr || root->getRight() == nodePtr) 
			return(root);	//We've found our guy!
		else if (!root->isLeaf()) {
			BNode<tpl>* left = root->getLeft();
			BNode<tpl>* right = root->getRight();

			ret = findParentByNode(nodePtr, left);  //Go left
			if (ret == NULL)
				findParentByNode(nodePtr, right); //Go right
		} else
			return(NULL);
	}
	else
		return(NULL);	//We couldn't find our person
}


/* Mutator Functions
 ****************************************************************************/
template <class tpl>
void BinarySearchTree<tpl>::clear(BNode<tpl>*& root) {
	if (root != NULL) {
		//Clear the left subtree
		clear(root->getLeftForUpdate());
		//Clear the right subtree
		clear(root->getRightForUpdate());
		delete root;	//get rid of the root node
		root = NULL;	//clear out the pointer
	}
}

template <class tpl>
bool BinarySearchTree<tpl>::insert(tpl data, BNode<tpl>* root) {
	bool ret = false;	//True if data has been inserted

	if (root == NULL) { //If there's no node here
		root = new BNode<tpl>(data, NULL, NULL); //create one
		m_root = root;
		ret = true;
	} else if (root->getData() == data) {
		Person temp = root->getData();
		temp.incrementCount();
		root->setData(temp);
		ret = true;
	} else if (data < root->getData()) {
		if (root->getLeft() == NULL) {
			root->getLeftForUpdate() = new BNode<Person>(data,NULL,NULL);
			ret = true;
		} else
			ret = insert(data, root->getLeft()); //go left and insert there
	} else if (data > root->getData()) {
		if (root->getRight() == NULL) {
			root->getRightForUpdate() = new BNode<Person>(data,NULL,NULL);
			ret = true;
		} else
			ret = insert(data, root->getRight()); //go right and insert there
	}

	return(ret);
}

template <class tpl>
bool BinarySearchTree<tpl>::deleteByData(tpl data, BNode<tpl>*& root) {
	bool ret = false;	//True if data has been deleted
	BNode<tpl>* nodePtr = NULL; //Points to condemned node
	BNode<tpl>* left = NULL;
	BNode<tpl>* right = NULL;

	if (root != NULL)
		nodePtr = find(data, m_root);

	if (nodePtr != NULL) 
		ret = deleteByNode(nodePtr);
	else 
		ret = NULL;

	return(ret);
}

template <class tpl>
bool BinarySearchTree<tpl>::deleteByNode(BNode<tpl>*& nodePtr) {
	bool ret = false;	//True if data has been deleted

	if (nodePtr != NULL) {
		if (nodePtr->isLeaf()) { //If root is a leaf, lop it off
			BNode<tpl>* parent = findParentByNode(nodePtr, m_root);
			if (parent != NULL) {
				if (parent->getLeft() == nodePtr)
					parent->setLeft(NULL);
				else
					parent->setRight(NULL);
			}
			delete nodePtr;

			if (nodePtr == m_root)
				m_root = NULL;

			ret = true;
		} else {
			if (nodePtr->getLeft()) {	//if there's a left node
				//move the max on the left subtree to the current spot
				BNode<tpl>* locOfMax = nodePtr->getLeft();
				BNode<tpl>* parentOfMax = nodePtr;
				while (locOfMax->getRight() != NULL) {
					parentOfMax = locOfMax;
					locOfMax = locOfMax->getRight();
				}
				
				tpl newData = locOfMax->getData();
				nodePtr->setData(newData);
				ret = true;
				
				//Lop off our max node
				if (locOfMax->getLeft() || parentOfMax == nodePtr) {
					//If our max has a left pal
					parentOfMax->setLeft(locOfMax->getLeft());
				} else {
					parentOfMax->setRight(NULL);
				}

				delete locOfMax;
			} else { //otherwise move the right node up
				if (nodePtr != NULL) {
					//moving data's bad. Let's move some pointers!
					BNode<tpl>* parentPtr = findParentByNode(nodePtr, m_root);

					if (nodePtr == m_root) {
						//If we're dealing with the tree's root
						m_root = nodePtr->getRight();
					} else {
						if (parentPtr->getRight() == nodePtr) {
							//Promote the deceased node's right node
							parentPtr->setRight(nodePtr->getRight());
						} else {
							//Promote the deceased node's left node
							parentPtr->setLeft(nodePtr->getLeft());
						}
					}
					
					delete nodePtr;
					ret = true;
					
					//tpl newData = nodePtr->getRight()->getData();
					//nodePtr->setData(newData);
					//ret = true;

					//Lop off the right node
					//BNode<tpl>* right = nodePtr->getRight();
					//deleteByNode(right);
				}
			}
		}
	}

	return(ret);
}