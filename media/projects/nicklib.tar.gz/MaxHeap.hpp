/****************************************************************************
 * MaxHeap.hp p                 Templated Binary Max. Heap declarations
 *
 * Programmer: Nick Pegg		Date: April 19, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Binary Maximum Heap class. Similar to a Binary Search Tree,
 * but is not well-sorted. Each parent is greater than its children.
 * 
 ****************************************************************************/

#include <cassert>

using namespace std;

/* Constructors/Destructors
 ****************************************************************************/
template <class tpl>
MaxHeap<tpl>::MaxHeap() {
	m_capacity = 10;
	m_numNodes = 0;
	m_indexOfLastNode = -1;
	m_data = new tpl[m_capacity];
}

template <class tpl>
MaxHeap<tpl>::MaxHeap(const int initCapacity) {
	assert(initCapacity > 0);

	m_capacity = initCapacity;
	m_numNodes = 0;
	m_indexOfLastNode = -1;
	m_data = new tpl[m_capacity];
}

template <class tpl>
MaxHeap<tpl>::MaxHeap(MaxHeap& oldHeap) {
	if (oldHeap.getCapacity() < 1) {
		//oldHeap is empty, so just create a plain-jane heap
		m_capacity = 10;
		m_data = new tpl[m_capacity];
		m_numNodes = 0;
		m_indexOfLastNode = -1;
	} else {
		//otherwise copy everything over
		m_capacity = oldHeap.getCapacity();
		m_data = new tpl[m_capacity];
		m_indexOfLastNode = -1;
		m_numNodes = 0;

		//copy the nodes over
		while (m_numNodes < oldHeap.getNumNodes())	{
			m_indexOfLastNode++;
			m_data[m_indexOfLastNode] = 
				oldHeap.getNodeData(m_indexOfLastNode);
			m_numNodes++;
		}
	}
}

template <class tpl>
MaxHeap<tpl>::~MaxHeap() {
	delete [] m_data;
}


/* Accessors
 ****************************************************************************/
template <class tpl>
tpl MaxHeap<tpl>::getNodeData(const int index) {
	assert(index > -1);
	assert(index < m_capacity);
	
	return (m_data[index]);
}

template <class tpl>
int MaxHeap<tpl>::getIndexOfParent(const int index) {
	assert(index > -1);
	assert(index < m_capacity);
	
	int parentIndex = (index - 1) / 2;

	if (parentIndex < -1) 
		return (-1);
	else
		return (parentIndex);
}

template <class tpl>
int MaxHeap<tpl>::getIndexOfLeft(const int index) {
	assert(index > -1);
	assert(index < m_capacity);

	leftIndex = 2 * index + 1;

	if (leftIndex > m_capacity)
		return (-1);
	else
		return (leftIndex);
}

template <class tpl>
int MaxHeap<tpl>::getIndexOfRight(const int index) {
	assert(index > -1);
	assert(index < m_capacity);

	rightIndex = 2 * index + 2;

	if (rightIndex > m_capacity)
		return (-1);
	else
		return (rightIndex);
}

template <class tpl>
bool MaxHeap<tpl>::findData(const tpl data) {
	bool ret = false;

	for (int i=0; i<m_capacity; i++) {
		if (m_data[i] == data)
			ret = true;
	}

	return (ret);
}


/* Mutators
 ****************************************************************************/
template <class tpl>
void MaxHeap<tpl>::insertNode(tpl newData) {
	//Make sure we have room for the data
	if (m_indexOfLastNode == m_capacity - 1)
		expandArray();

	//Insert the data
	m_data[++m_indexOfLastNode] = newData;
	m_numNodes++;

	//Check if heap needs to be reorganized
	checkHeapReverse(m_indexOfLastNode);
}

template <class tpl>
tpl MaxHeap<tpl>::popNode() {
	tpl temp;

	if (m_numNodes > 0) {
		temp = m_data[0];
		m_data[0] = m_data[m_indexOfLastNode--];
		m_numNodes--;

		checkHeap(0);
	}

	return (temp);
}

template <class tpl>
void MaxHeap<tpl>::setNodeData(const int index, tpl newData) {
	assert(index > -1);
	assert(index < m_capacity);

	m_data[index] = newData;
}

template <class tpl>
void MaxHeap<tpl>::expandArray() {
	tpl* temp = new tpl[m_capacity + 5];

	for (int i=0; i < m_capacity; i++) {
		temp[i] = m_data[i];
	}

	//Cleanup
	delete [] m_data;
	m_data = temp;
	m_capacity += 5;
}

template <class tpl>
void MaxHeap<tpl>::checkHeap(int rootIndex) {
	assert(rootIndex > -1);
	assert(rootIndex < m_capacity);

	//Be sure that there are left and right children
	if (m_numNodes < rootIndex*2+1 || 
		m_data[rootIndex*2+1].getPriority() == 0) 
	{
		return;
	} 
	if (m_numNodes < rootIndex*2+2 || 
		m_data[rootIndex*2+2].getPriority() == 0) 
	{
		return;
	}

	//Check to see if a child value is greater than the one at our root
	while (m_data[rootIndex] < m_data[rootIndex*2+1] || 
		   m_data[rootIndex] < m_data[rootIndex*2+2]) 
	{
		bool rMax = false;
		bool lMax = false;

		if (m_data[rootIndex*2+1] < m_data[rootIndex*2+2])
			rMax = true;
		else
			lMax = true;

		if (m_data[rootIndex] < m_data[rootIndex*2+1] && lMax) { 
			//Swap root with left
			tpl temp = m_data[rootIndex];
			m_data[rootIndex] = m_data[rootIndex*2+1];
			m_data[rootIndex*2+1] = temp;
		} else if (m_data[rootIndex] < m_data[rootIndex*2+2] && rMax) {
			//Swap root with right
			tpl temp = m_data[rootIndex];
			m_data[rootIndex] = m_data[rootIndex*2+2];
			m_data[rootIndex*2+2] = temp;
		}
	}

	//Check the left subtree
	checkHeap(rootIndex * 2 + 1);

	//Check the right subtree
	checkHeap(rootIndex * 2 + 2);
}

template <class tpl>
void MaxHeap<tpl>::checkHeapReverse(int index) {
	assert(index < m_capacity);

	tpl pVal;
	int pIndex = getIndexOfParent(index);

	//Be sure that parent exists
	if (pIndex > -1) {
		pVal = m_data[pIndex];

		if (pVal < m_data[index]) {
			//swap with the parent
			tpl temp = m_data[index];
			m_data[index] = m_data[pIndex];
			m_data[pIndex] = temp;

			//Check to see if we need to keep moving
			checkHeapReverse(pIndex);
		}
	}
}
