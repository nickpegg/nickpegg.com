/****************************************************************************
 * DNode.h						Templated DNode class (used in DLinkedLists)
 *
 * Programmer: Nick Pegg		Date: Feb 17, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Doubly-linked Node class. Contains data and a pointer to 
 * the previous and next node in the list.
 * 
 ****************************************************************************/

#ifndef DNODE_H
#define DNODE_H

#include <iostream>
#include <cstring>

using namespace std;

template <class NODEDATA> 
class DNode {
	private:
		NODEDATA m_data;
		int m_priority;
		DNode *m_next;
		DNode *m_prev;
	public:
		//Constructors/Destructors
		DNode(NODEDATA initData, DNode* initNext, DNode* initPrev);
		~DNode();

		//Accessors
		NODEDATA getData() const { return m_data; }
		DNode* getNext() const { return m_next; }
		DNode* getPrev() const { return m_prev; }

		//Mutators
		void setData(const NODEDATA newData);
		void setNext(DNode* newLink);
		void setPrev(DNode* newLink);
};

#include "DNode.hpp"

#endif //DNODE_H
