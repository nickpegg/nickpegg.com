/****************************************************************************
 * Node.cpp						Node members function implementations
 *
 * Programmer: Nick Pegg		Date: Feb 06, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Node class. Contains data and a pointer to another node.
 *
 ****************************************************************************/

#include "stdafx.h"
#include "Node.h"


/****************************************************************************
 * Node class functions
 ****************************************************************************/

//Default Constructor
//PRE: initData contains valid data, initLink is a valid pointer
//POST: Node data is set and link points to other node or NULL
Node::Node(NODEDATA initData, Node* initLink) {
	m_data = initData;
	m_link = initLink;
}

//Default Destructor
//PRE: None
//POST: None
Node::~Node() {
	//Insert code as necessary
}


/* Mutator Functions
 ****************************************************************************/

//Sets m_data to newData
//PRE: newData contains valid NODEDATA
//POST m_data contains valid data
void Node::setData(const NODEDATA newData) {
	m_data = newData;
}

//Sets m_link to newLink
//PRE: newLink contains a valid link
//POST m_link contains a valid link
void Node::setLink(Node* newLink) {
	m_link = newLink;
}