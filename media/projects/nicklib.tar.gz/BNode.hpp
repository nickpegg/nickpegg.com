/****************************************************************************
 * BNode.hpp                    Templated BNode function implementations
 *
 * Programmer: Nick Pegg		Date: March 29, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Binary Search Tree Node class. Contains data, a pointer to the
 * left node, and a pointer to the right node.
 * 
 ****************************************************************************/

//See BNode.h for Preconditions and Postconditions


/* Constructor/Destructor
 ****************************************************************************/
template <class tpl>
BNode<tpl>::BNode(tpl initData, BNode *initLeft, BNode *initRight) {
	m_data = initData;
	m_left = initLeft;
	m_right = initRight;
}

template <class tpl>
BNode<tpl>::~BNode() {
	//Insert code as neccessary
}


/* Accessor Functions
 ****************************************************************************/
template <class tpl>
bool BNode<tpl>::isLeaf() {
	return ((m_left == NULL) && (m_right == NULL));
}


/* Mutator Functions
 ****************************************************************************/
template <class tpl>
void BNode<tpl>::setData(tpl newData) {
	m_data = newData;
}

template <class tpl>
void BNode<tpl>::setLeft(BNode* newLeft) {
	m_left = newLeft;
}
template <class tpl>
void BNode<tpl>::setRight(BNode* newRight) {
	m_right = newRight;
}