/****************************************************************************
 * Stack.hpp                    Templated Stack function implementations
 *
 * Programmer: Nick Pegg		Date: Feb 22, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Stack class, a Last-In First-Out container
 *
 ****************************************************************************/


/* Constructors/Destructors
 ****************************************************************************/

//Default constructor
//PRE: none
//POST: headPtr and tailPtr = Null, m_numItems = 0
template <class tpl>
Stack<tpl>::Stack() {
	
}

//Default destructor
//PRE: none
//POST: none
template <class tpl>
Stack<tpl>::~Stack() {
	//insert any necessary code here
}


/* Accessor functions
 ****************************************************************************/

//Returns the top item in the stack
//PRE: Stack contains valid data
//POST: Top item in stack is returned
template <class tpl>
tpl Stack<tpl>::top() {
	if (getHeadPtr() != NULL) {
		return(getHeadPtr()->getData());
	}
	else return(NULL);
}


/* Mutator functions
 ****************************************************************************/

//Adds a new item to the top of the stack
//PRE: item contains valid data
//POST: item is new top of node
template <class tpl>
void Stack<tpl>::push(tpl item) {
	insertAtHead(item);
}

//Removes and returns the top item of the stack
//PRE: Stack contains valid data
//POST: Top item is removed from stack and returned
template <class tpl>
tpl Stack<tpl>::pop() {
	if (getHeadPtr() != NULL) { //Avoid a stack underflow
		tpl temp = getHeadPtr()->getData();
		removeHeadNode();
		return(temp);
	} else {
		return(NULL);
	}
}
