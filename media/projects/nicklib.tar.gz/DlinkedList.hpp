/****************************************************************************
 * DLinkedList.hpp              Templated DLinkedList function implementations
 *
 * Programmer: Nick Pegg		Date: Feb 22, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the DLinkedList class. Manages a group of nodes via pointers.
 *
 ****************************************************************************/
 

/* Constructors/Destructors
 ****************************************************************************/

//Default Constructor
//PRE: none	
//POST: headPtr and tailPtr point to null
template <class tpl>
DLinkedList<tpl>::DLinkedList() {
	headPtr = NULL;
	tailPtr = NULL;
	m_numItems = 0;
}

//Default Destructor
//PRE: none
//POST: Linked list is emptied (all memory given back)
template <class tpl>
DLinkedList<tpl>::~DLinkedList() {
	clearContents();	//empty the array
}

/* Accessors
 ****************************************************************************/

//Finds the nth node in the linked list, starting at 0
//PRE: index >= 0, index < number of nodes
//POST: returns pointer to nth item in linked list
template <class tpl>
DNode<tpl>* DLinkedList<tpl>::findNodeByIndex(const int index) {
	assert(index >= 0);

	DNode *cursor;
	int count = 0;

	for (cursor = getHeadPtr(); cursor != NULL; cursor = cursor->getNext()) {
		if (count == index) {	//If we've found the Node...
            return(cursor);		//return a pointer to it.
		} else {				
			count++;			//Otherwise keep going
		}
	}

	return(NULL);	//We never found it
}

/* Mutators
 ****************************************************************************/

//Inserts a new node at the head of the linked list
//PRE: newData contains valid NODEDATA
//POST: node created at head of list, headPtr points to new node
template <class tpl>
void DLinkedList<tpl>::insertAtHead(const tpl newData) {
	DNode<tpl> *ptrToNewNode = new DNode<tpl>(newData, NULL, NULL);
	
	ptrToNewNode->setNext(headPtr);
	if (headPtr != NULL)
		headPtr->setPrev(ptrToNewNode);
	else {	//update tailPtr if necessary
		if (headPtr == NULL)
			tailPtr = ptrToNewNode;
	}

	headPtr = ptrToNewNode; 
	m_numItems++;
}

//Inserts a new node at the tail of the linked list
//PRE: newData contains valid NODEDATA
//POST: node created on end of linked list, tailPtr points to new node
template <class tpl>
void DLinkedList<tpl>::insertAtTail(const tpl newData) {
	if (tailPtr != NULL) { 
		DNode<tpl> *ptrToNewNode = new DNode<tpl>(newData, NULL, NULL);

		tailPtr->setNext(ptrToNewNode);
		ptrToNewNode->setPrev(tailPtr);
		tailPtr = ptrToNewNode;

		m_numItems++;
	} else {
		insertAtHead(newData);	//assume that we're starting a new linked list
	}
}

//Inserts a new node after the node at ptrToPrevNode
//PRE: newData is valid NODEDATA
//POST: new node is placed after *ptrToPrevNode, pointing to *ptrToPrevNode's
//      old friend and to *ptrToPrevNode
template <class tpl>
void DLinkedList<tpl>::insert(const tpl newData, DNode<tpl>* ptrToPrevNode) {
	if (ptrToPrevNode != NULL && headPtr != NULL && tailPtr != NULL) {
		DNode *ptrToNewNode = new DNode(newData, NULL, NULL);
		DNode *ptrToNextNode = ptrToPrevNode->getNext();

		ptrToNewNode->setNext(ptrToNextNode);
		ptrToNewNode->setPrev(ptrToPrevNode);

		ptrToPrevNode->setNext(ptrToNewNode);
		if (ptrToNextNode == NULL)
			tailPtr = ptrToNewNode;
		else
            ptrToNextNode->setPrev(ptrToNewNode);

		m_numItems++;
	} else {
		insertAtHead(newData);	//assume we're putting the new item at the head
	}	
}

//Removes the first node in the linked list
//PRE: Linked List contains nodes
//POST: the first node is removed, *headPtr points to the next, head node's
//		Prev points to NULL
template <class tpl>
void DLinkedList<tpl>::removeHeadNode() {
	if (headPtr != NULL) {	//If a head node exists...
		DNode<tpl> *temp = headPtr;
		DNode<tpl> *ptrToNext = headPtr->getNext();
		
		headPtr = ptrToNext;
		if (ptrToNext != NULL)
			ptrToNext->setPrev(NULL);
		
		delete temp;
	} else if (headPtr == NULL) {
		tailPtr = headPtr; //update tailPtr
	}

	m_numItems--;
} 

//Removes the last node in the linked list
//PRE: ptrToPrevNode does not point to the tail node
//POST: last node is removed, tailPtr points to the new last node
template <class tpl>
void DLinkedList<tpl>::removeTailNode() {
	if (tailPtr != NULL) {
		DNode *ptrToPrevNode = tailPtr->getPrev();

		ptrToPrevNode->setNext(NULL);	//Forget about the condemned node
		delete tailPtr;					//Get rid of it
		tailPtr = ptrToPrevNode;		//Point tailPtr to the new tail
	}

	m_numItems--;
}

//Removes a node based on a pointer to it
//PRE: ptrToNode points to a valid node
//POST: *ptrToPrevNode points to the next node in line, *ptrToPrevNode points 
//      to previous node in line, skipped node removed
template <class tpl>
void DLinkedList<tpl>::removeNode(DNode<tpl>* ptrToNode) {
	if (ptrToNode != NULL) {
		DNode *ptrToPrevNode = ptrToNode->getPrev();
		DNode *ptrToNextNode = ptrToNode->getNext();

		if (ptrToNode == headPtr)		//If the condemned node is the head
			headPtr = ptrToNextNode;	// update the head pointer
		if (ptrToNode == tailPtr) 		//If the condemned node is the tail
			tailPtr = ptrToPrevNode;	// update the tail pointer
	
		//Skip over the condemned node
		if (ptrToPrevNode != NULL)
            ptrToPrevNode->setNext(ptrToNextNode);
		if (ptrToNextNode != NULL)
			ptrToNextNode->setPrev(ptrToPrevNode);

		delete ptrToNode;		//Get rid of the old node
	} else {
		removeHeadNode();	//Assume we're removing the head node
	}
	
	m_numItems--;
}

//Removes all nodes in the linked list
//PRE: none
//POST: Linked List contains no nodes, headPtr and tailPtr are NULL
template <class tpl>
void DLinkedList<tpl>::clearContents() {
	DNode<tpl> *temp;

	while (headPtr != NULL) {
		temp = headPtr;
		headPtr = headPtr->getNext();	//Abandon the node headPtr points to
		delete temp;					// and delete it.
	}

	tailPtr = NULL;						//Update tailPtr
	m_numItems = 0;
}

 
 
