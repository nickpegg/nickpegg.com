/****************************************************************************
 * MaxHeap.h                    Templated Binary Max. Heap class
 *
 * Programmer: Nick Pegg		Date: April 19, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Binary Maximum Heap class. Similar to a Binary Search Tree,
 * but is not well-sorted. Each parent is greater than its children.
 * 
 ****************************************************************************/

#ifndef MAXHEAP_H
#define MAXHEAP_H

using namespace std;

/**** Preconditions and Postconditions ****/
//MaxHeap()
//PRE: none
//POST: capacity set to 10, data array created, numNodes set to 0, 
//      indexOfLastNode set to -1

//MaxHeap(const int initCapacity);
//PRE: initCapacity > 0
//POST: capacity set to initCapacity, data array created, numNodes set to 0,
//      indexOfLastNode set to -1

//MaxHeap(const MaxHeap& oldHeap);
//PRE: oldHeap is a valid heap
//POST: if oldHeap doesn't contain any nodes, the new heap is empty. Otherwise
//      the data from oldHeap is copied to the new heap

//~MaxHeap();
//PRE: none
//POST: all data is deleted

//int getNumNodes()
//PRE: none
//POST: returns number of nodes in heap

//int getCapacity()
//PRE: none
//POST: returns the capacity of the data array

//tpl getNodeData(const int index);
//PRE: -1 < index < m_capacity
//POST: returns the data at m_data[index]

//int getIndexOfParent(const int index);
//PRE: -1 < index < m_capacity
//POST: returns the index of the parent of m_data[index] if it exists

//int getIndexOfLeft(const int index);
//PRE: -1 < index < m_capacity
//POST: returns the index of the left child if it exists

//int getIndexOfRight(const int index);
//PRE: -1 < index < m_capacity
//POST: returns the index of the right child if it exists

//bool findData(const tpl data);
//PRE: data is valid heap data
//POST: returns true if data exists in heap, otherwise returns false

//void insertNode(tpl newData);
//PRE: newData is valid data
//POST: numNodes increments, newData moves up as necessary

//tpl popNode();
//PRE: Heap has at least one node
//POST: returns the top node, the last node is at the top of the heap, heap is
//      rearranged as necessary

//void setNodeData(const int index, tpl newData);
//PRE: -1 < index < m_capacity, newData is valid data
//POST: data at m_data[index] is now newData

//void expandArray();
//PRE: none
//POST: data array is expanded by 5

//void checkHeap(int rootIndex);
//PRE: -1 < rootIndex < m_capacity
//POST: if a child of rootIndex is greater than rootIndex's value, the greater
//      of the two children are swapped with root.

//void checkHeapReverse(int index);
//PRE: -1 < rootIndex < m_capacity
//POST: if the parent of index is less than index's value, then index's value
//      is swapped with the parent's value


template <class tpl>
class MaxHeap {
	private:
		tpl* m_data;
		int m_capacity;
		int m_numNodes;
		int m_indexOfLastNode;

	public:
		//Constructors/Destructors
		MaxHeap();
		MaxHeap(const int initCapacity);
		MaxHeap(MaxHeap& oldHeap);
		~MaxHeap();

		//Accessors
		int getNumNodes() { return(m_numNodes); }
		int getCapacity() { return(m_capacity); }
		tpl getNodeData(const int index);
		int getIndexOfParent(const int index);
		int getIndexOfLeft(const int index);
		int getIndexOfRight(const int index);
		bool findData(const tpl data);

		//Mutators
		void insertNode(tpl newData);
		tpl popNode();
		void setNodeData(const int index, tpl newData);
		void expandArray();
		void checkHeap(int rootIndex);
		void checkHeapReverse(int index);
};

#include "MaxHeap.hpp"

#endif //MAXHEAP_H