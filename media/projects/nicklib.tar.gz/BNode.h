/****************************************************************************
 * BNode.hpp               Templated BNode class (used in Binary Search Tree)
 *
 * Programmer: Nick Pegg		Date: March 29, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Binary Search Tree Node class. Contains data, a pointer to the
 * left node, and a pointer to the right node.
 * 
 ****************************************************************************/

#ifndef BNODE_H
#define BNODE_H


/**** Preconditions/Postconditions ****/

//BNode(NODEDATA initData, BNode *initLeft, BNode *initRight) - Constructor
//PRE: initData contains valid NODEDATA, initLeft and initRight are valid
//POST: initial values are set and links point to either BNodes or NULL

//~BNode() - Destructor
//PRE: none
//POST: none

//getData()
//PRE: m_data contains valid data
//POST: returns m_data

//getLeft()
//PRE: m_left is valid link or NULL
//POST: return m_left

//getLeftForUpdate()
//PRE: m_left is valid link or NULL
//POST: returns m_left by reference

//getRight()
//PRE: m_right is valid link or NULL
//POST: return m_right

//getRightForUpdate()
//PRE: m_right is valid link or NULL
//POST: returns m_right by reference

//isLeaf()
//PRE: none
//POST: returns true if left and right links are both NULL, otherwise false

//setData(NODEDATA newData)
//PRE: newData is valid NODEDATA
//POST: m_data contains valid data

//setLeft(BNode* newLeft)
//PRE: newLeft is a valid link or NULL
//POST: m_left is valid link or NULL

//setRight(BNode* newRight)
//PRE: newRight is a valid link or NULL
//POST: m_right is valid link or NULL


template <class NODEDATA>
class BNode {
	private:
		//Variables
		NODEDATA m_data;
		BNode *m_left;
		BNode *m_right;

	public:
		//Constructor/Destructor
		BNode(NODEDATA initData, BNode *initLeft, BNode *initRight);
		~BNode();

		//Accessors
		NODEDATA getData() { return(m_data); }
		BNode* getLeft() { return(m_left); }
		BNode*& getLeftForUpdate() { return(m_left); }
		BNode* getRight() { return(m_right); }
		BNode*& getRightForUpdate() { return(m_right); }
		bool isLeaf();

		//Mutators
		void setData(NODEDATA newData);
		void setLeft(BNode* newLeft);
		void setRight(BNode* newRight);
};

#include "BNode.hpp" //Include function implementations

#endif //BNODE_H