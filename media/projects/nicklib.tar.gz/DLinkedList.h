/****************************************************************************
 * DLinkedList.h				Templated DLinkedList class
 *
 * Programmer: Nick Pegg		Date: Feb 22, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the DLinkedList class. Manages a group of nodes via pointers.
 *
 ****************************************************************************/


#ifndef DLINKEDLIST_H
#define DLINKEDLIST_H

#include "DNode.h"
#include <cassert>

template <class DLLDATA>
class DLinkedList {
	private:
		DNode<DLLDATA> *headPtr;
		DNode<DLLDATA> *tailPtr;
		int m_numItems;

	public:
		//Constructor/Destructor
		DLinkedList();
		~DLinkedList();

		//Accessors
		DNode<DLLDATA>* getHeadPtr() { return(headPtr); }
		DNode<DLLDATA>* getTailPtr() { return(tailPtr); }
		DNode<DLLDATA>* findNodeByIndex(const int index);
		int getNumItems() { return(m_numItems); }

		//Mutators
		void insertAtHead(const DLLDATA newData);
		void insertAtTail(const DLLDATA newData);
		void insert(const DLLDATA newData, DNode<DLLDATA>* ptrToPrevNode);
		void removeHeadNode();
		void removeTailNode();
		void removeNode(DNode<DLLDATA>* ptrToNode);
		void clearContents();
};

#include "DLinkedList.hpp"

#endif //DLINKEDLIST_H
