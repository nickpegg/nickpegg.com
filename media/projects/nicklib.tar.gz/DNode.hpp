/****************************************************************************
 * DNode.hpp                    Templated DNode function implementations
 *
 * Programmer: Nick Pegg		Date: Feb 17, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Doubly-linked Node class. Contains data and a pointer to 
 * the previous and next node in the list.
 * 
 ****************************************************************************/
 

//Default Constructor
//PRE: initData contains valid data, initLink is a valid pointer
//POST: DNode data is set and link points to other node or NULL
template <class NODEDATA>
DNode<NODEDATA>::DNode(NODEDATA initData, DNode* initNext, DNode* initPrev) {
	m_data = initData;
	m_next = initNext;
	m_prev = initPrev;
	m_priority = 0;
}

//Default Destructor
//PRE: None
//POST: None
template <class NODEDATA>
DNode<NODEDATA>::~DNode() {
	//Insert code as necessary
}


/* Mutator Functions
 ****************************************************************************/

//Sets m_data to newData
//PRE: newData contains valid NODEDATA
//POST m_data contains valid data
template <class NODEDATA>
void DNode<NODEDATA>::setData(const NODEDATA newData) {
	m_data = newData;
}

//Sets m_next to newLink
//PRE: newLink contains a valid link
//POST m_prev contains a valid link
template <class NODEDATA>
void DNode<NODEDATA>::setNext(DNode* newLink) {
	m_next = newLink;
}

//Sets m_prev to newLink
//PRE: newLink contains a valid link
//POST m_prev contains a valid link
template <class NODEDATA>
void DNode<NODEDATA>::setPrev(DNode* newLink) {
	m_prev = newLink;
}
