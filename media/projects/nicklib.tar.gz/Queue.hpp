/****************************************************************************
 * Queue.hpp                    Templated Queue function implementations
 *
 * Programmer: Nick Pegg		Date: Feb 28, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Queue class, a First-In First-Out container
 *
 ****************************************************************************/

/* Constructors/Destructors
 ****************************************************************************/

//Default constructor
//PRE: none
//POST: headPtr and tailPtr = Null, m_numItems = 0
template <class tpl>
Queue<tpl>::Queue() {
	//insert any necessary code here
}

//Default destructor
//PRE: none
//POST: none
template <class tpl>
Queue<tpl>::~Queue() {
	//insert any necessary code here
}


/* Accessor functions
 ****************************************************************************/

//Returns the top item in the queue
//PRE: Queue contains valid data
//POST: Top item in queue is returned
template <class tpl>
tpl Queue<tpl>::top() {
	tpl temp = NULL
	if (getHeadPtr() != NULL) {	//Avoid queue underflow
		temp = getHeadPtr()->getData();
	}
	
	return(temp);
}


/* Mutator functions
 ****************************************************************************/

//Adds a new item to the top of the queue
//PRE: item contains valid data
//POST: item is new top of node
template <class tpl>
void Queue<tpl>::enqueue(tpl item) {
	insertAtTail(item);
}

//Removes and returns the top item of the queue
//PRE: Queue contains valid data
//POST: Top item is removed from queue and returned
template <class tpl>
tpl Queue<tpl>::dequeue() {
	tpl temp = NULL;

	if (getHeadPtr() != NULL) { //Avoid a queue underflow
		temp = getHeadPtr()->getData();
		removeHeadNode();
	}

	return(temp);
}
