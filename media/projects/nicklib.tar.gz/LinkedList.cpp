/****************************************************************************
 * LinkedList.cpp				LinkedList member function implementations
 *
 * Programmer: Nick Pegg		Date: Feb 06, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the LinkedList class. Manages a group of nodes via pointers.
 *
 ****************************************************************************/

#include "stdafx.h"
#include "LinkedList.h"
#include <cassert>

using namespace std;


/* Constructors/Destructors
 ****************************************************************************/

//Default Constructor
//PRE: none	
//POST: headPtr and tailPtr point to null
LinkedList::LinkedList() {
	headPtr = NULL;
	tailPtr = NULL;
	m_numItems = 0;
}

//Default Destructor
//PRE: none
//POST: Linked list is emptied (all memory given back)
LinkedList::~LinkedList() {
	clearContents();	//empty the array
}

/* Accessors
 ****************************************************************************/

//Finds the nth node in the linked list, starting at 0
//PRE: index >= 0, index < number of nodes
//POST: returns pointer to 
Node* LinkedList::findNodeByIndex(const int index) {
	assert(index >= 0);

	Node *cursor;
	int count = 0;

	for (cursor = getHeadPtr(); cursor != NULL; cursor = cursor->getLink()) {
		if (count == index) {	//If we've found the Node...
            return(cursor);		//return a pointer to it.
		} else {				
			count++;			//Otherwise keep going
		}
	}

	return(NULL);	//We never found it
}

/* Mutators
 ****************************************************************************/

//Inserts a new node at the head of the linked list
//PRE: newData contains valid NODEDATA
//POST: node created at head of list, headPtr points to new node
void LinkedList::insertAtHead(const NODEDATA newData) {
	Node *ptrToNewNode = new Node(newData, NULL); 
	
	ptrToNewNode->setLink(headPtr); 

	//update tailPtr if necessary
	if (headPtr == NULL)
		tailPtr = ptrToNewNode;

	headPtr = ptrToNewNode; 
	m_numItems++;
}

//Inserts a new node at the tail of the linked list
//PRE: newData contains valid NODEDATA
//POST: node created on end of linked list, tailPtr points to new node
void LinkedList::insertAtTail(const NODEDATA newData){
	if (tailPtr != NULL) { 
		Node *ptrToNewNode = new Node(newData, NULL);

		tailPtr->setLink(ptrToNewNode);
		tailPtr = ptrToNewNode;
	} else {
		insertAtHead(newData);	//assume that we're starting a new linked list
	}

	m_numItems++;
}

//Inserts a new node after the node at ptrToPrevNode
//PRE: newData is valid NODEDATA
//POST: new node is placed after *ptrToPrevNode, pointing to *ptrToPrevNode's
//      old friend
void LinkedList::insert(const NODEDATA newData, Node* ptrToPrevNode){
	if (ptrToPrevNode != NULL) {
		Node *ptrToNewNode = new Node(newData, ptrToPrevNode->getLink());

		ptrToPrevNode->setLink(ptrToNewNode);

	} else {
		insertAtHead(newData);	//assume we're putting the new item at the head
	}
	m_numItems++;
}

//Removes the first node in the linked list
//PRE: Linked List contains nodes
//POST: the first node is removed, headPtr points to the next
void LinkedList::removeHeadNode() {
	if (headPtr != NULL) {	//If a head node exists...
		Node *temp = headPtr;

		headPtr = headPtr->getLink();
		delete temp;
	} else if (headPtr == NULL) {
		tailPtr = headPtr; //update tailPtr
	}

	m_numItems--;
} 

//Removes the last node in the linked list
//PRE: ptrToPrevNode does not point to the tail node
//POST: last node is removed, tailPtr points to the new last node
void LinkedList::removeTailNode(Node* ptrToPrevNode) {
	if (tailPtr != NULL) {
		ptrToPrevNode->setLink(NULL);	//Forget about the condemned node
		delete tailPtr;					//Get rid of it
		tailPtr = ptrToPrevNode;		//Point to the new tail
	}

	m_numItems--;
}

//Removes a node based on a pointer to it
//PRE: 
//POST: *ptrToPrevNode points to the next node in line, skipped node removed
void LinkedList::removeNode(Node* ptrToPrevNode) {
	if (ptrToPrevNode != NULL) {
		Node *temp = ptrToPrevNode->getLink();  //Point temp to condemned node
		if (temp == tailPtr) {			//If the condemned node is the tail...
			tailPtr = ptrToPrevNode;	// update the tail pointer
		}
	
		ptrToPrevNode->setLink(temp->getLink());//Skip over the condemned node
		delete temp;		//Get rid of the old node
	} else {
		removeHeadNode();	//assume we're removing the head node
	}
	
	m_numItems--;
}

//Removes all nodes in the linked list
//PRE: none
//POST: Linked List contains no nodes, headPtr and tailPtr are NULL
void LinkedList::clearContents() {
	Node *temp;

	while (headPtr != NULL) {
		temp = headPtr;
		headPtr = headPtr->getLink();	//Abandon the node headPtr points to
		delete temp;					// and delete it.
	}
	tailPtr = NULL;						//Update tailPtr
	m_numItems = 0;
}