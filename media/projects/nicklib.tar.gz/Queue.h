/****************************************************************************
 * Queue.h						Templated Queue class
 *
 * Programmer: Nick Pegg		Date: Feb 28, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Queue class, a First-In First-Out container
 *
 ****************************************************************************/

#ifndef QUEUE_H
#define QUEUE_H

#include "DLinkedList.h"

template <class QUEUEDATA>
class Queue : public DLinkedList<QUEUEDATA> {
	//No additional member variables needed...
	public:
		//Constructors/Destructors
		Queue();
		~Queue();

		//Accessor functions
		QUEUEDATA top();

		//Mutator functions
		void enqueue(QUEUEDATA item);
		QUEUEDATA dequeue();

};

#include "Queue.hpp"

#endif	//QUEUE_H
