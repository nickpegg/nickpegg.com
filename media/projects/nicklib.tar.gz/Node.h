/****************************************************************************
 * Node.h						Node class - primarily used for Linked Lists
 *
 * Programmer: Nick Pegg		Date: Feb 06, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Node class. Contains data and a pointer to another node.
 * 
 ****************************************************************************/

#ifndef NODE_H
#define NODE_H

#include <iostream>
#include <cstring>

using namespace std;


// PROGRAM-SPECIFIC CODE - CHANGE AS NEEDED 
#include "groceryItem.h"

typedef groceryItem NODEDATA;

// END PROGRAM-SPECIFIC CODE


class Node {
	private:
		NODEDATA m_data;
		Node *m_link;
	public:
		//Constructors/Deconstructors
		Node(NODEDATA initData, Node* initLink);
		~Node();

		//Accessors
		NODEDATA getData() const { return m_data; }
		Node* getLink() const { return m_link; }

		//Mutators
		void setData(const NODEDATA newData);
		void setLink(Node* newLink);
};

#endif //NODE_H
