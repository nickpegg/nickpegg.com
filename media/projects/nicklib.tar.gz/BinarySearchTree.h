/****************************************************************************
 * BinarySearchTree.h           Templated Binary Search Tree class
 *
 * Programmer: Nick Pegg		Date: March 29, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Binary Search Tree class: a collection of nodes which contain
 * data and links to two other nodes. Does not allow duplicates.
 * 
 ****************************************************************************/

#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H

#include "BNode.h"

/**** Preconditions/Postconditions ****/
//BinarySearchTree()
//PRE: none
//POST: m_root points to NULL

//~BinarySearchTree()
//PRE: none
//POST: Tree is empty, all nodes deleted

//getRoot()
//PRE: none
//POST:	returns m_root

//getRootForUpdate()
//PRE: none
//POST: returns m_root by refernce

//BNode<BSTDATA>* find(BSTDATA data, BNode<BSTDATA>* root)
//PRE: data is valid BSTDATA, root points to node in tree
//POST: If data is the tree, a pointer to the node which contains 
//      data is returned.

//BNode<BSTDATA>* findParent(BSTDATA data, BNode<BSTDATA>* root)
//PRE: data is valid BSTDATA, root points to node in tree
//POST: If data is the tree, a pointer to the parent of the node which 
//      contains data is returned.

//setRoot(BNode<BSTDATA>* newRoot)
//PRE: none
//POST: m_root is now set to newRoot

//void clear(BNode<BSTDATA>*& root)
//PRE: root points to node in tree
//POST: all nodes in root's subtree are deleted (including root)

//bool insert(BSTDATA data, BNode<BSTDATA>* root);
//PRE: data is valid BSTDATA, root points to node in a tree
//POST: A node containing data is inserted according to the BST rules:
//          If new value > root's value, insert right
//          If new value < root's value, insert left
//		Returns successfulness of insertion

//bool deleteByData(BSTDATA data, BNode<BSTDATA>*& root)
//PRE: data is valid BSTDATA, root points to node in a tree
//POST: Node containing the data is removed according to BST rules,
//      returns successfulness of deletion

//bool deleteByNode(BNode<BSTDATA>*& nodePtr)
//PRE: nodePtr points to valid node in tree
//POST: Node is removed according to BST rules, 
//      returns successfulness of deletion


template <class BSTDATA>
class BinarySearchTree {
	private:
		//Variables
		BNode<BSTDATA> *m_root;

	public:
		//Constructors/Destructors
		BinarySearchTree() { m_root = NULL; }
		~BinarySearchTree() { clear(m_root); }

		//Accessors
		BNode<BSTDATA>* getRoot() { return(m_root); }
		BNode<BSTDATA>*& getRootForUpdate() { return(m_root); }
		BNode<BSTDATA>* find(BSTDATA data, BNode<BSTDATA>* root);
		BNode<BSTDATA>* findParent(BSTDATA data, BNode<BSTDATA>* root);
		BNode<BSTDATA>* findParentByNode(BNode<BSTDATA>* nodePtr, BNode<BSTDATA>* root);

		//Mutators
		void setRoot(BNode<BSTDATA>* newRoot) { m_root = newRoot; }
		void clear(BNode<BSTDATA>*& root);
		bool insert(BSTDATA data, BNode<BSTDATA>* root);
		bool deleteByData(BSTDATA data, BNode<BSTDATA>*& root);
		bool deleteByNode(BNode<BSTDATA>*& nodePtr);
};

#include "BinarySearchTree.hpp"

#endif //BINARYSEARCHTREE_H