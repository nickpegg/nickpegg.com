/****************************************************************************
 * Stack.h						Templated Stack class
 *
 * Programmer: Nick Pegg		Date: Feb 22, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the Stack class, a Last-In First-Out container
 *
 ****************************************************************************/

#ifndef STACK_H
#define STACK_H

#include "DLinkedList.h"

template <class STACKDATA>
class Stack : public DLinkedList<STACKDATA> {
	//No additional member variables needed...
	public:
		//Constructors/Destructors
		Stack();
		~Stack();

		//Accessor functions
		STACKDATA top();

		//Mutator functions
		void push(STACKDATA item);
		STACKDATA pop();

};

#include "Stack.hpp"

#endif	//STACK_H
