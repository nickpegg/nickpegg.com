/****************************************************************************
 * LinkedList.h					LinkedList class
 *
 * Programmer: Nick Pegg		Date: Feb 06, 2006       
 * Instructor: Dr. Leopold
 * 
 * Defines the LinkedList class. Manages a group of nodes via pointers.
 *
 ****************************************************************************/

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Node.h"


class LinkedList {
	private:
		Node *headPtr;
		Node *tailPtr;
		int m_numItems;

	public:
		//Constructor/Destructor
		LinkedList();
		~LinkedList();

		//Accessors
		Node* getHeadPtr() { return(headPtr); }
		Node* getTailPtr() { return(tailPtr); }
		Node* findNodeByIndex(const int index);
		int getNumItems() { return(m_numItems); }

		//Mutators
		void insertAtHead(const NODEDATA newData);
		void insertAtTail(const NODEDATA newData);
		void insert(const NODEDATA newData, Node* ptrToPrevNode);
		void removeHeadNode();
		void removeTailNode(Node* ptrToPrevNode);
		void removeNode(Node* ptrToPrevNode);
		void clearContents();
};

#endif //LINKEDLIST_H