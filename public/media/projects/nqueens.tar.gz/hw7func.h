/****************************************************************************
 * hw7func.h                    HW #7 functions
 *
 * Programmer: Nick Pegg		Date: March 12, 2006       
 * Instructor: Dr. Leopold
 * 
 ****************************************************************************/

#ifndef HW7FUNC_H
#define HW7FUNC_H

#include <iostream>
#include <cassert>

void outputBoard(bool **queens, int n);

bool placeQueen(bool **queens, int n, int col);

bool checkPosition(bool **queens, int n, int x, int y);

#endif //HW7FUNC_H