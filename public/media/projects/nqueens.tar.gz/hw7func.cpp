/****************************************************************************
 * hw7func.cpp                  HW #7 function implementations
 *
 * Programmer: Nick Pegg		Date: March 12, 2006       
 * Instructor: Dr. Leopold
 * 
 ****************************************************************************/

#include "hw7func.h"

using namespace std;

//Outputs the current board with size n x n
//PRE: queens points to valid 2D array, 8 <= n <= 16
//POST: Current board is outputted to console
void outputBoard(bool **queens, int n) {
	cout << "+";
	for (int i=0; i < n; i++) {
		cout << "-+";
	}
	cout << endl;

	//Step through array and output queens
	for (int i=0; i < n; i++) {	//rows
		for (int j=0; j < n; j++) { //columns
			cout << "|";
			if (queens[i][j])
				cout << "Q";
			else
				cout << " ";
		}
		cout << "|" << endl;
	}

	cout << "+";
	for (int i=0; i < n; i++) {
		cout << "-+";
	}
	cout << endl;
}

//Places a queen in a valid spot
//PRE: queens points to valid 2D array, n is > 0, 0 < col < n
//POST: Queens are placed on board if a valid solution exists
bool placeQueen(bool **queens, int n, int col) {
	assert(n > 0 && col < n);

	bool valid = false;
	int row;

	//run down board in column to try and find a valid spot
	for (row=0; row < n && !valid; row++) {
		valid = checkPosition(queens, n, col, row);

		//If a valid spot has been found, place a queen there
		if (valid) {
			queens[col][row] = true;
		}

		//And find a spot for the next queen
		if (valid && col + 1 < n) {
			valid = placeQueen(queens, n, col + 1);

			//If the next queen can't be placed, remove the current one
			if (!valid)
				queens[col][row] = false;
		}
	}

	//Return whether or not there's a valid solution going
	return valid;
}


//Checks to see if placing a queen in spot (x,y) is valid
//PRE: queens points to valid 2D array; n >0; x and y are between -1 and n
//POST: returns true if (x,y) is a valid spot
bool checkPosition(bool **queens, int n, int x, int y) {
	//Check for stupid programmers
	assert(queens != NULL);
	assert(n > 0);
	assert(x >= 0 && y >= 0);
	assert(x < n && y < n);

	bool valid = true;	//true if queen can be placed at (x,y)
	int i, j;

	//No need to check forwards or vertically...
	
	//Check horizontally
	j = y;
	for (i = x; i >= 0 && valid; i--) {
		if (queens[i][j])
			valid = false;
	}

	//Check diagonals
	//Up and left
	for (i=x, j=y; i >= 0 && j >= 0 && valid; i--, j--) {
		if (queens[i][j])
			valid = false;
	}

	//Down and left
	for (i=x, j=y; i >= 0 && j < n && valid; i--, j++) {
		if (queens[i][j])
			valid = false;
	}

	return valid;
}