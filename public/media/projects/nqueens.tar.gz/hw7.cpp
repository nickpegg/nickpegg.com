/****************************************************************************
 * hw7.cpp                      HW #7 - N-Queens Problem
 *
 * Programmer: Nick Pegg		Date: March 12, 2006       
 * Instructor: Dr. Leopold
 * 
 * Finds a solution to the queens problem and displays the first solution 
 * found. 
 * 
 ****************************************************************************/
#include <cstring>
#include "hw7func.h"

using namespace std;


int main(int argc, char* argv[])
 {
	//Variables
	bool **queens;      //pointer to 2D array containing queens
	bool manualInput = false;	//True if input by cin instead of command-line
	int numRowsCols;    //number of rows and columns
	int numSolutions = 1;	//number of solutions to find

	//Grab number of rows and columns
	if (argc < 2) {
		cout<<"Please enter the size of a chessboard between 8 and 16.";
		cout << endl << endl;
		cout << "Usage: hw7.exe n" << endl;
		cout << "Where n = number of columns and rows on the board." << endl;
		cout << endl;
		system("pause");  //Keep Windows from just closing the console
		exit(1);
	} else {	//From command-line argument
		numRowsCols = atoi(argv[1]);
	
	}

	if (numRowsCols > 16 || numRowsCols < 8) {
		cout<<"Please enter the size of a chessboard between 8 and 16.";
		cout << endl << endl;
		cout << "Usage: hw7.exe n" << endl;
		cout << "Where n = number of columns and rows on the board." << endl;
		cout << endl;
		system("pause");  //Keep Windows from just closing the console
		exit(1);
	}


	//Output console header razamatazz
	for (int i=0; i < 79; i++)
		cout << "+";
	cout << endl << " N-Queens Solver" << endl;
	cout << " Using N = " << numRowsCols << " Rows and Columns." << endl;
	for (int i=0; i < 79; i++)
		cout << "+";
	cout << endl << endl;


	//Allocate memory for the queens array
	queens = new bool*[numRowsCols];

	for (int i=0; i < numRowsCols; i++) {
		queens[i] = new bool[numRowsCols];
		if (!queens[i]) {
			cout << "Memory allocation error!";
			exit(1);
		}
	}

	//Set the board as initially empty
	for (int i=0; i < numRowsCols; i++) {
		for (int j=0; j<numRowsCols; j++) {
			queens[i][j] = false;
		}
	}

	bool solution = placeQueen(queens, numRowsCols, 0);
	if (solution) 
		outputBoard(queens, numRowsCols);
	 else
		cout << endl << endl << "A valid solution was not found!" << endl;

	system("pause");  //Keep Windows from just closing the console


	//Cleanup
	for (int i=0; i < numRowsCols; i++) {
		delete [] queens[i];
	}

	delete [] queens;

	return 0;
}

