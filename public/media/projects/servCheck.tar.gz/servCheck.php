<?php
#################################################################
# servCheck - simple PHP service checker
# Written by Nick Pegg
# http://c0nkat.net/
# 
# Originally written for TerminalUnix
# Modified to be more portable and to only update once a minute
#
# There is no warranty. If this does something bad, I claim no responsibility. 
#################################################################

$ver = "1.1";	//Version number


	//Setup the probe function
	function probe_server($port, $host) {
		$fp = fsockopen ($host, $port, $errno, $errstr, 10);
		if (!$fp) {
				// CHANGEME - Change this to where you store your images. An absolute path may help.
    			return "<img src=\"http://terminalunix.com/images/red.gif\" alt='Down'>\n"; 
		} else { 
			fclose($fp);
				// CHANGEME
	    		return "<img src=\"http://terminalunix.com/images/green.gif\" alt='Up'>\n"; 
		}
	}


	if (is_writable("output.html")) {
		//Open output.html
		if (!$handle = fopen("output.html", 'w')) {
	    		die ("Error: Cannot open file output.html");
		}
	
		//Copy the header parts to output.html	
		fwrite($handle, "<!-- Begin ServCheck v$ver Report -->\n");
		fwrite($handle, "<!-- ServCheck is written by Nick Pegg -->\n");
		fwrite($handle, "<!-- Website: http://c0nkat.net/ -->\n");
		fwrite($handle, "<table border=0 cellpadding=0 cellspacing=0>\n");
		
		//Read config file into array
		if ($file = file("servCheck.conf")) {
			//Work with file line-by-line
			foreach ($file as $line) {
				if (substr($line, 0, 1) != '#') {	//if not a comment
					list($desc, $host, $port) = split(":", $line);
			
					fwrite($handle, "<tr><td width=50>$desc</td>\n");
				    fwrite($handle, "<td><center>". probe_server($port, $host) . "</center></td>\n");	
					fwrite($handle, "</tr>\n");
				}
			}	
		}
	
		//Insert the tail parts into output.html
		fwrite($handle, "</table>\n");
		fwrite($handle, "<!-- Generated ".date("H:i:s M d, Y")."-->\n");
		fwrite($handle, "<!-- End ServCheck Report -->");
		fclose($handle);
				
			
		$handle = fopen("lastcheck",'w');
		fwrite($handle, time());
		fclose($handle);
	} else {
		die ("Cannot open output.html for writing! Check the permissions.");
	}
?>
