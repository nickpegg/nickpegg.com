/*
 * USB CPU meter driver program
 * Written by Nick Pegg - Fall 2007
 * http://nickpegg.com/?page=cpulights
 *
 * Compilation: g++ -o cpu_meter main.cpp -lserial -lstatgrab
 *
 * IMPORTANT NOTE: my light bytes are reversed because I'm an idiot and wired
 * up the LEDs in reverse order. 0x01 turns into 0x80
 */

#include <iostream>
#include <string>

#include <signal.h>         //Signal handling

#include <statgrab.h>       //libstatgrab
#include <SerialStream.h>   //libserial

using namespace std;
using namespace LibSerial;
                        
void printUsage(char *);

int main(int argc, char * argv[]) {
    //Variable declarations
    char byte;
    float cpuUsage;
    sg_cpu_percents *cpuStats;
    
    if (argc < 2) {
        printUsage(argv[0]);
        exit(1);
    }
    
    //Open the serial port
    SerialStream port(argv[1]);
    if (!port.IsOpen()) {
        cerr << "ERROR: Unable to open serial port!" << endl << endl;
        printUsage(argv[0]);
        exit(1);
    }
    
    while (true) {
        //Find the percentage of CPU used
        cpuStats = sg_get_cpu_percents();
        cpuUsage = 100.0 - cpuStats->idle;
        
        //Determine the byte to send
        if (cpuUsage < 11.1) {
            byte = 0x00;
        } else if (cpuUsage < 22.2) {
            byte = 0x80;
        } else if (cpuUsage < 33.3) {
            byte = 0xc0;
        } else if (cpuUsage < 44.4) {
            byte = 0xe0;
        } else if (cpuUsage < 55.5) {
            byte = 0xf0;
        } else if (cpuUsage < 66.6) {
            byte = 0xf8;
        } else if (cpuUsage < 77.7) {
            byte = 0xfc;
        } else if (cpuUsage < 88.8) {
            byte = 0xfe;
        } else if (cpuUsage < 100) {
            byte = 0xff;
        }
        
        
        //cout << "CPU Usage: " << cpuUsage << endl;
        port << byte;
        usleep(500000);
    }
    
    return 0;
}

void printUsage(char *exec) {
    cout << "Usage: " << exec << " [serial device]" << endl << endl;
    cout << "Example: " << exec << " /dev/ttyUSB0" << endl;
}
